'use strict';
const { expect } = require('chai'),
    TimeEntries = require('../model/timeEntries');

var time = new Date().toISOString().substr(0, 19);

describe('Time entries test', function () {
    it('Should list all time entries', function (done) {
        TimeEntries.getAllTimeEntries(
            {
                requestContext: {
                    resourcePath: '/v1/time-entries',
                    httpMethod: 'GET'
                }
            }
        )
            .then(result => {
                expect(result).to.be.an("Array");
                return done();
            })
            .catch(error => {
                return done(error);
            });
    });
    it('Should list all specified user\'s task sorted by most recent to the oldest', function (done) {
        TimeEntries.getTimeEntriesByUserId(
            {
                requestContext: {
                    resourcePath: '/v1/user/{id}/time-entries',
                    httpMethod: 'GET'
                },
                pathParams: {
                    id: '1'
                }
            })
            .then(result => {
                //expect(result).to.be.a("Array");
                expect(result).to.not.be.lengthOf(0);
                return done();
            })
            .catch(error => {
                return done(error);
            });
    });
    it('Specified user should not have time entries', function (done) {
        TimeEntries.getTimeEntriesByUserId(
            {
                requestContext: {
                    resourcePath: '/v1/user/{id}/time-entries',
                    httpMethod: 'GET'
                },
                pathParams: {
                    id: '-1'
                }
            }
        )
            .then(result => {
                expect(result).to.be.lengthOf(0);
                return done();
            })
            .catch(error => {
                return done(error);
            });
    });
    /*it('Should be able to create a time entry with no description', function (done) {
        TimeEntries.createTimeEntry(
            {
                requestContext: {
                    resourcePath: '/v1/time-entries',
                    httpMethod: 'POST'
                },
                body: {
                    "task_id": null,
                    "description": null,
                    "start": time,
                    "stop": null,
                    "user_id": "1",
                    "project_id": null
                }
            }
        )
        .then(result => {
            expect(result).to.be.empty;
            return done();
        })
        .catch(error => {
            return done(error);
        });
    });*/
    /*it('Should be able to create a time entry manually (start-stop time and duration)', function (done) {
        TimeEntries.createTimeEntry(
            {
                requestContext: {
                    resourcePath: '/v1/time-entries',
                    httpMethod: 'POST'
                },
                body: {
                    "task_id": null,
                    "description": "Test task with start stop time " + time,
                    "start": time,
                    "stop": time,
                    "duration": 0,
                    "user_id": "1",
                    "project_id": null
                }
            }
        )
        .then(result => {
            expect(result).to.be.empty;
            return done();
        })
        .catch(error => {
            return done(error);
        });
    });*/
    it('Should be able to update a time entry for only project_id, stop, duration, description and task_id', function (done) {
        TimeEntries.createTimeEntry(
            {
                requestContext: {
                    resourcePath: '/v1/time-entries/{id}',
                    httpMethod: 'PUT'
                },
                body: {
                    "task_id": null,
                    "description": "Updated task from a test " + time,
                    "start": time,
                    "stop": time,
                    "duration": 0,
                    "user_id": "1",
                    "project_id": null
                },
                pathParams: {
                    id: '--'
                }
            }
        )
        .then(result => {
            expect(result).to.be.empty;
            return done();
        })
        .catch(error => {
            return done(error);
        });
    });

});